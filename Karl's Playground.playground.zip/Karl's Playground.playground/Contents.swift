//: Playground - noun: a place where people can play

import UIKit

// Standard 1st program print statement! 

print("Hello World!")


//Variables and Constants
var myVariable = 42
myVariable = 50
let myConstant = 42


// Specifying the data type
let implicitInteger = 70
let implicitDouble = 70.0
let explicitDouble: Double = 70
let explicitFloat = 4


// converting values to a different type
let label = "The width is "
let width = 94
let widthLabel = label + String(width)


// A simpler way to include values in strings using a backslash (\)

let apples = 3
let oranges = 5
let appleSummary = "I have \(apples) apples"
let fruitSummary = "I have \(apples + oranges) pieces of fruit"

//Including a floating-point calculation in a string and someones name in a greeting 

let rectLength = 3.63
let rectWidth = 3.25
let rectArea = "The area of the rectangle is \(rectLength*rectWidth) cms"

let someonesName = "Karl"
let greeting = "It's good to meet you \(someonesName)"


//Creating an array and dictionaries using brackets ([]), nd accessing their elements by writing the index or key in brackets

var shoppingList = ["catfish", "water", "tulips","blue paint"]
shoppingList[1] = "bottle of water"

print(shoppingList[1])

var occupations = ["Malcolm": "Captain",
                   "Kaylee": "Mechanic",
]

occupations["Jayne"] = "Public Relations"

print(occupations)

//Creating an empty array or dictionary using the initialiser syntax

let emptyArray = [String]()
let emptyDictionary = [String: Float]()

// if the type information can be inferred 

shoppingList = []
occupations = [:]



